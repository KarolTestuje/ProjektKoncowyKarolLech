import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

public class MyStepdefs {

    WebDriver webDriver;
    WebDriverWait wait;

    @Before
    public void otwieramPrzeglądarke() {
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\Karol\\OneDrive\\Pulpit\\UdemyKursSelenium\\Drivery\\chromedriver-win64 (1)\\chromedriver-win64\\chromedriver.exe");
        webDriver = new ChromeDriver();
        webDriver.manage().window().maximize();
        wait = new WebDriverWait(webDriver, 3);
        webDriver.get("https://demo.guru99.com/v4/");
    }

    @Given("Jestem zalogowany jako Manager do aplikacji webowej Guru Bank loginem: {string} i hasłem: {string}")
    public void jestemZalogowanyJakoManagerDoAplikacjiWebowejGuruBankLoginemIHasłem(String login, String haslo) {
        webDriver.findElement(By.cssSelector("table:nth-child(2) tbody:nth-child(1) tr:nth-child(1) td:nth-child(2) > input:nth-child(1)")).sendKeys(login);
        webDriver.findElement(By.cssSelector("table:nth-child(2) tbody:nth-child(1) tr:nth-child(2) td:nth-child(2) > input:nth-child(1)")).sendKeys(haslo);
        webDriver.findElement(By.cssSelector("body > form > table > tbody > tr:nth-child(3) > td:nth-child(2) > input[type=submit]:nth-child(1)")).click();
    }

    @When("Klikam zakładkę New Customer")
    public void klikamZakładkęNewCustomer() {
        webDriver.findElement(By.cssSelector("body > div:nth-child(6) > div > ul > li:nth-child(2) > a")).click();
    }

    @When("Wprowadzam poprawne dane kilenta")
    public void wprowadzamPoprawneDaneKilenta() {
        webDriver.findElement(By.cssSelector("body > table > tbody > tr > td > table > tbody > tr:nth-child(4) > td:nth-child(2) > input[type=text]")).sendKeys("Name Less");
        webDriver.findElement(By.cssSelector("body > table > tbody > tr > td > table > tbody > tr:nth-child(5) > td:nth-child(2) > input[type=radio]:nth-child(1)")).click();
        webDriver.findElement(By.xpath("/html[1]/body[1]/table[1]/tbody[1]/tr[1]/td[1]/table[1]/tbody[1]/tr[6]/td[2]/input[1]")).sendKeys("04.03.1997");
        webDriver.findElement(By.cssSelector("body > table > tbody > tr > td > table > tbody > tr:nth-child(7) > td:nth-child(2) > textarea")).sendKeys("Aydontknow");
        webDriver.findElement(By.cssSelector("body > table > tbody > tr > td > table > tbody > tr:nth-child(8) > td:nth-child(2) > input[type=text]")).sendKeys("Where");
        webDriver.findElement(By.cssSelector("body > table > tbody > tr > td > table > tbody > tr:nth-child(9) > td:nth-child(2) > input[type=text]")).sendKeys("Ayem");
        webDriver.findElement(By.cssSelector("body > table > tbody > tr > td > table > tbody > tr:nth-child(10) > td:nth-child(2) > input[type=text]")).sendKeys("123456");
        webDriver.findElement(By.cssSelector("body > table > tbody > tr > td > table > tbody > tr:nth-child(11) > td:nth-child(2) > input[type=text]")).sendKeys("123123123");
        webDriver.findElement(By.cssSelector("body > table > tbody > tr > td > table > tbody > tr:nth-child(12) > td:nth-child(2) > input[type=text]")).sendKeys("super@coool.mail");
        webDriver.findElement(By.cssSelector("body > table > tbody > tr > td > table > tbody > tr:nth-child(13) > td:nth-child(2) > input[type=password]")).sendKeys("supermocnehaslo");

    }

    @Then("Nie pojawiają się żadne komunikaty obok sekcji do uzupełnienia")
    public void niePojawiająSięŻadneKomunikatyObokSekcjiDoUzupełnienia() {
    }

    @When("klikam przycisk Submit")
    public void klikamPrzyciskSubmit() {
        webDriver.findElement(By.cssSelector("body > table > tbody > tr > td > table > tbody > tr:nth-child(14) > td:nth-child(2) > input[type=submit]:nth-child(1)")).click();
    }

    @Then("Przechodzę na stronę z danymi konta nowego klienta")
    public void przechodzęNaStronęZDanymiKontaNowegoKlienta() {
    }

    @When("Klikam przycisk continue")
    public void klikamPrzyciskContinue() {
    }

    @Then("Wracam do zakładki Manager")
    public void wracamDoZakładkiManager() {
    }

    @After
    public void zamykamPrzegladarke() {
        webDriver.quit();
    }
}

